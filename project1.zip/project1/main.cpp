#include"change.h"
#include"Sm3_optimize.h"


#define max_num 65536//2^16
string inlist[max_num];
string outlist[max_num];

void BirthdayAttack() {
	string str;
	string result;
	string paddingValue;
	for (int i = 0; i < max_num; outlist[i++] = result) {
		cout << "目前进度：" << i << endl;
		str = to_string(i);
		inlist[i] = str;
		paddingValue = padding(str);
		result = iteration(paddingValue);
		//查找储存的表尝试找到一对碰撞
		for (int j = 0; j < i; j++) {
			if (outlist[j].substr(0, 4) == result.substr(0, 4)) {
				cout << endl;
				cout << "collision string input 1 :" + str << endl << endl;
				cout << "collision hash value 1:" << endl;
				cout << result.substr(0, 8) << "  ";
				cout << result.substr(8, 8) << "  ";
				cout << result.substr(16, 8) << "  ";
				cout << result.substr(24, 8) << "  ";
				cout << result.substr(32, 8) << "  ";
				cout << result.substr(40, 8) << "  ";
				cout << result.substr(48, 8) << "  ";
				cout << result.substr(56, 8) << "  ";
				cout << endl;
				cout << "collision string input 2 :" + inlist[j] << endl << endl;
				cout << "collision hash value 2:" << endl;
				cout << outlist[j].substr(0, 8) << "  ";
				cout << outlist[j].substr(8, 8) << "  ";
				cout << outlist[j].substr(16, 8) << "  ";
				cout << outlist[j].substr(24, 8) << "  ";
				cout << outlist[j].substr(32, 8) << "  ";
				cout << outlist[j].substr(40, 8) << "  ";
				cout << outlist[j].substr(48, 8) << "  ";
				cout << outlist[j].substr(56, 8) << "  ";
				cout << endl << "finding num in all:  " << i;
				return;
			}
		}
	}
	cout << "Birthday Attack Failed!";
}

int main() {
	BirthdayAttack();
	return 0;
}
